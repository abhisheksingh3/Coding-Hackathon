<?php

namespace App\Http\Controllers;

use App\Models\Call;
use App\Services\OpenAiCallAnalysisService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use RuntimeException;
use Throwable;

class CallController extends Controller
{
    public function index(Request $request): View
    {
        $query = Call::query();

        $searchTerm = trim((string) $request->input('q', ''));
        if ($searchTerm !== '') {
            $like = '%'.addcslashes($searchTerm, '%_\\').'%';
            $query->where(function ($q) use ($like) {
                $q->where('transcript', 'like', $like)
                    ->orWhere('ai_summary', 'like', $like)
                    ->orWhere('conversation_quality', 'like', $like)
                    ->orWhere('keywords', 'like', $like);
            });
        }

        if ($request->filled('sentiment')) {
            $s = $request->string('sentiment')->toString();
            if (in_array($s, Call::sentiments(), true)) {
                $query->where('sentiment', $s);
            }
        }

        if ($request->filled('date_from')) {
            $from = $request->date('date_from');
            if ($from) {
                $query->whereDate('created_at', '>=', $from);
            }
        }

        if ($request->filled('date_to')) {
            $to = $request->date('date_to');
            if ($to) {
                $query->whereDate('created_at', '<=', $to);
            }
        }

        $calls = $query->latest()->paginate(15)->withQueryString();

        $filters = [
            'q' => $searchTerm,
            'sentiment' => $request->input('sentiment', ''),
            'date_from' => $request->input('date_from', ''),
            'date_to' => $request->input('date_to', ''),
        ];

        $filtersActive = $searchTerm !== ''
            || $request->filled('sentiment')
            || $request->filled('date_from')
            || $request->filled('date_to');

        $totalCallsInDb = Call::query()->count();

        return view('calls.index', compact('calls', 'filters', 'filtersActive', 'totalCallsInDb'));
    }

    public function show(Call $call): View
    {
        return view('calls.show', compact('call'));
    }

    public function destroy(Call $call): RedirectResponse
    {
        $path = $call->audio_file_path;
        if (is_string($path) && $path !== '') {
            Storage::disk('public')->delete($path);
        }

        $call->delete();

        return redirect()
            ->route('calls.index')
            ->with('success', 'Call deleted.');
    }

    /**
     * Stream recording from storage (works without php artisan storage:link).
     */
    public function recording(Call $call): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        $path = $call->audio_file_path;
        $disk = Storage::disk('public');

        if ($path === '' || ! $disk->exists($path)) {
            abort(404);
        }

        $mime = $disk->mimeType($path);

        return $disk->response($path, basename($path), [
            'Content-Type' => is_string($mime) && $mime !== '' ? $mime : 'application/octet-stream',
        ]);
    }

    public function create(): View
    {
        return view('calls.create');
    }

    public function store(Request $request, OpenAiCallAnalysisService $ai): RedirectResponse|JsonResponse
    {
        $incoming = $request->file('audio');
        if ($incoming instanceof UploadedFile && ! $incoming->isValid()) {
            $iniHint = sprintf(
                ' This PHP process reports upload_max_filesize=%s, post_max_size=%s (SAPI: %s).',
                ini_get('upload_max_filesize') ?: '?',
                ini_get('post_max_size') ?: '?',
                PHP_SAPI
            );
            $msg = match ($incoming->getError()) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'File exceeds server upload limits (PHP post_max_size / upload_max_filesize).'.$iniHint.' From the project folder run: php artisan serve (not plain php -S), or raise those values in the php.ini used by your web SAPI (e.g. php-fpm pool). App limit is 25 MB for Whisper.',
                UPLOAD_ERR_PARTIAL => 'Upload was interrupted — try again.',
                UPLOAD_ERR_NO_FILE => 'No file was received — choose a file and submit again.',
                UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE, UPLOAD_ERR_EXTENSION => 'Server could not store the upload — check disk space and PHP temp directory.',
                default => 'Upload failed (PHP error '.$incoming->getError().').',
            };

            if ($request->expectsJson()) {
                return response()->json(['message' => $msg, 'errors' => ['audio' => [$msg]]], 422);
            }

            return back()->withInput()->withErrors(['audio' => $msg]);
        }

        $validated = $request->validate([
            'audio' => ['required', 'file', 'max:25600', 'mimes:mp3,wav,m4a,ogg,webm,aac,flac'],
        ]);

        $uploaded = $validated['audio'];
        $path = $uploaded->store('calls', 'public');

        try {
            $disk = Storage::disk('public');
            $fullPath = $disk->path($path);

            $transcription = $ai->transcribe($fullPath, $uploaded->getClientOriginalName());
            $analysis = $ai->analyzeTranscript($transcription['text'], $transcription['duration_seconds']);

            Call::query()->create([
                'audio_file_path' => $path,
                'transcript' => $transcription['text'],
                'transcript_segments' => $transcription['segments'],
                'duration_seconds' => $transcription['duration_seconds'],
                ...$analysis,
            ]);
        } catch (Throwable $e) {
            Storage::disk('public')->delete($path);

            report($e);

            $errMsg = $e instanceof RuntimeException ? $e->getMessage() : 'AI processing failed. Try again.';

            if ($request->expectsJson()) {
                return response()->json(['message' => $errMsg, 'errors' => ['audio' => [$errMsg]]], 422);
            }

            return back()
                ->withInput()
                ->withErrors(['audio' => $errMsg]);
        }

        if ($request->expectsJson()) {
            $successMsg = 'Recording processed and saved.';
            session()->flash('success', $successMsg);

            return response()->json([
                'redirect' => route('calls.index'),
                'message' => $successMsg,
            ]);
        }

        return redirect()
            ->route('calls.index')
            ->with('success', 'Recording processed and saved.');
    }
}
