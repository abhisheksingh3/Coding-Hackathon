<?php

namespace App\Http\Controllers;

use App\Models\Call;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $totalCalls = Call::query()->count();

        $sentimentRows = Call::query()
            ->select('sentiment', DB::raw('COUNT(*) as cnt'))
            ->groupBy('sentiment')
            ->pluck('cnt', 'sentiment')
            ->all();

        $sentimentPositive = (int) ($sentimentRows[Call::SENTIMENT_POSITIVE] ?? 0);
        $sentimentNeutral = (int) ($sentimentRows[Call::SENTIMENT_NEUTRAL] ?? 0);
        $sentimentNegative = (int) ($sentimentRows[Call::SENTIMENT_NEGATIVE] ?? 0);

        $avgScore = Call::query()->whereNotNull('overall_call_score')->avg('overall_call_score');
        $avgDurationSeconds = Call::query()->whereNotNull('duration_seconds')->avg('duration_seconds');

        $totalActionItems = 0;
        $keywordCounts = [];
        foreach (Call::query()->cursor() as $call) {
            $items = $call->action_items;
            $totalActionItems += is_array($items) ? count($items) : 0;

            $kws = $call->keywords;
            if (is_array($kws)) {
                foreach ($kws as $kw) {
                    if (! is_string($kw)) {
                        continue;
                    }
                    $norm = mb_strtolower(trim($kw));
                    if ($norm === '') {
                        continue;
                    }
                    if (! isset($keywordCounts[$norm])) {
                        $keywordCounts[$norm] = ['label' => trim($kw), 'count' => 0];
                    }
                    $keywordCounts[$norm]['count']++;
                }
            }
        }

        uasort($keywordCounts, fn (array $a, array $b) => $b['count'] <=> $a['count']);
        $topKeywords = array_slice(array_values($keywordCounts), 0, 15);

        $insightTopBehavior = $this->topObservationInsightByCalls('positive_observations');
        $insightBiggestIssue = $this->topObservationInsightByCalls('negative_observations');
        $insightImprovementSummary = $this->buildImprovementSummary(
            $insightBiggestIssue,
            $insightTopBehavior,
            $totalCalls
        );

        $teamObjections = $this->rankedObservationInsightsByCalls('negative_observations', 5);
        $missedDiscovery = $this->aggregateMissedDiscoveryTopics();
        $teamSalesSuggestions = $this->buildTeamSalesSuggestions(
            $teamObjections,
            $missedDiscovery['items'],
            $insightTopBehavior,
            $totalCalls,
            $missedDiscovery['calls_with_coverage']
        );

        return view('dashboard', [
            'totalCalls' => $totalCalls,
            'sentimentPositive' => $sentimentPositive,
            'sentimentNeutral' => $sentimentNeutral,
            'sentimentNegative' => $sentimentNegative,
            'avgScore' => $avgScore !== null ? round((float) $avgScore, 1) : null,
            'avgDurationLabel' => $this->formatDurationSeconds($avgDurationSeconds !== null ? (float) $avgDurationSeconds : null),
            'totalActionItems' => $totalActionItems,
            'topKeywords' => $topKeywords,
            'insightTopBehavior' => $insightTopBehavior,
            'insightBiggestIssue' => $insightBiggestIssue,
            'insightImprovementSummary' => $insightImprovementSummary,
            'teamObjections' => $teamObjections,
            'teamMissedDiscovery' => $missedDiscovery['items'],
            'callsWithDiscoveryCoverage' => $missedDiscovery['calls_with_coverage'],
            'teamSalesSuggestions' => $teamSalesSuggestions,
        ]);
    }

    /**
     * Most common observation text across calls (each call counts at most once per normalized line).
     *
     * @return array{text: string, call_count: int}|null
     */
    private function topObservationInsightByCalls(string $field): ?array
    {
        $ranked = $this->rankedObservationInsightsByCalls($field, 1);

        return $ranked[0] ?? null;
    }

    /**
     * @return list<array{text: string, call_count: int}>
     */
    private function rankedObservationInsightsByCalls(string $field, int $limit): array
    {
        $callCounts = [];
        $labels = [];

        foreach (Call::query()->select([$field])->cursor() as $call) {
            $items = $call->{$field};
            if (! is_array($items)) {
                continue;
            }

            $keysInCall = [];
            foreach ($items as $line) {
                if (! is_string($line)) {
                    continue;
                }
                $trim = trim($line);
                if ($trim === '') {
                    continue;
                }
                $key = mb_strtolower(preg_replace('/\s+/u', ' ', $trim));
                $keysInCall[$key] = $trim;
            }

            foreach ($keysInCall as $key => $label) {
                if (! isset($callCounts[$key])) {
                    $callCounts[$key] = 0;
                    $labels[$key] = $label;
                }
                $callCounts[$key]++;
            }
        }

        if ($callCounts === []) {
            return [];
        }

        arsort($callCounts);

        $out = [];
        foreach (array_slice($callCounts, 0, $limit, true) as $key => $count) {
            $out[] = [
                'text' => $labels[$key],
                'call_count' => $count,
            ];
        }

        return $out;
    }

    /**
     * @return array{items: list<array{topic: string, missed_count: int}>, calls_with_coverage: int}
     */
    private function aggregateMissedDiscoveryTopics(): array
    {
        $topics = config('sales_discovery.topics', []);
        if (! is_array($topics)) {
            $topics = [];
        }

        $canonicalByLower = [];
        $missed = [];
        foreach ($topics as $t) {
            if (! is_string($t)) {
                continue;
            }
            $t = trim($t);
            if ($t === '') {
                continue;
            }
            $canonicalByLower[mb_strtolower($t)] = $t;
            $missed[$t] = 0;
        }

        $callsWithCoverage = 0;

        foreach (Call::query()->select(['discovery_coverage'])->cursor() as $call) {
            $cov = $call->discovery_coverage;
            if (! is_array($cov) || $cov === []) {
                continue;
            }

            $callsWithCoverage++;

            foreach ($cov as $row) {
                if (! is_array($row)) {
                    continue;
                }
                $topicRaw = trim((string) ($row['topic'] ?? ''));
                if ($topicRaw === '') {
                    continue;
                }
                $lk = mb_strtolower($topicRaw);
                if (! isset($canonicalByLower[$lk])) {
                    continue;
                }
                $canonical = $canonicalByLower[$lk];
                if (! empty($row['asked'])) {
                    continue;
                }
                $missed[$canonical]++;
            }
        }

        $items = [];
        foreach ($missed as $topic => $cnt) {
            if ($cnt > 0) {
                $items[] = ['topic' => $topic, 'missed_count' => $cnt];
            }
        }

        usort($items, fn (array $a, array $b) => $b['missed_count'] <=> $a['missed_count']);

        return [
            'items' => array_slice($items, 0, 8),
            'calls_with_coverage' => $callsWithCoverage,
        ];
    }

    /**
     * @param  list<array{text: string, call_count: int}>  $objections
     * @param  list<array{topic: string, missed_count: int}>  $missedTopics
     * @param  array{text: string, call_count: int}|null  $topBehavior
     * @return list<string>
     */
    private function buildTeamSalesSuggestions(
        array $objections,
        array $missedTopics,
        ?array $topBehavior,
        int $totalCalls,
        int $callsWithCoverage
    ): array {
        if ($totalCalls === 0) {
            return ['Upload and process calls to generate team-wide sales coaching suggestions.'];
        }

        $lines = [];

        if ($callsWithCoverage > 0 && $missedTopics !== []) {
            $top = $missedTopics[0];
            $pct = (int) round(100 * $top['missed_count'] / $callsWithCoverage);
            $lines[] = sprintf(
                'Prioritize discovery on "%s" — not meaningfully addressed in %d of %d calls with discovery data (%d%%).',
                $top['topic'],
                $top['missed_count'],
                $callsWithCoverage,
                $pct
            );
        }

        if (isset($missedTopics[1]) && $callsWithCoverage > 0) {
            $t = $missedTopics[1];
            $lines[] = sprintf(
                'Add coaching on "%s" (missed in %d calls).',
                $t['topic'],
                $t['missed_count']
            );
        }

        if ($objections !== []) {
            $lines[] = sprintf(
                'Run a team drill on objections tied to: %s',
                Str::limit($objections[0]['text'], 160)
            );
        }

        if (isset($objections[1])) {
            $lines[] = sprintf(
                'Also review patterns around: %s',
                Str::limit($objections[1]['text'], 120)
            );
        }

        if ($topBehavior !== null) {
            $lines[] = sprintf(
                'Replicate strengths reps already show: %s',
                Str::limit($topBehavior['text'], 130)
            );
        }

        if ($lines === []) {
            return [
                'Add more calls with AI discovery coverage and observation lists to unlock targeted team actions.',
            ];
        }

        return array_slice($lines, 0, 6);
    }

    /**
     * @param  array{text: string, call_count: int}|null  $biggestIssue
     * @param  array{text: string, call_count: int}|null  $topBehavior
     */
    private function buildImprovementSummary(?array $biggestIssue, ?array $topBehavior, int $totalCalls): string
    {
        if ($totalCalls === 0) {
            return 'Upload and process calls to surface team-wide coaching themes.';
        }

        if ($biggestIssue === null && $topBehavior === null) {
            return 'Add AI observations to more calls (or wait for richer transcripts) to unlock a tailored improvement plan.';
        }

        if ($biggestIssue === null) {
            $snippet = Str::limit($topBehavior['text'], 160);

            return sprintf(
                'Reinforce what is already working — reps are often recognized for: %s. Capture gaps in negative observations on future calls to sharpen priorities.',
                $snippet
            );
        }

        $issue = Str::limit($biggestIssue['text'], 220);
        $n = $biggestIssue['call_count'];
        $pct = $totalCalls > 0 ? (int) round(100 * $n / $totalCalls) : 0;

        $parts = [
            sprintf(
                'Prioritize coaching on the most repeated gap: %s — it shows up in %d of %d calls (%d%%).',
                $issue,
                $n,
                $totalCalls,
                $pct
            ),
        ];

        if ($topBehavior !== null) {
            $parts[] = sprintf(
                'Pair that with strengths you already see often, e.g. %s',
                Str::limit($topBehavior['text'], 140)
            );
        } else {
            $parts[] = 'Use call reviews to agree on one concrete behavior change and measure it on the next batch.';
        }

        return implode(' ', $parts);
    }

    private function formatDurationSeconds(?float $seconds): ?string
    {
        if ($seconds === null) {
            return null;
        }

        $s = (int) round($seconds);
        $m = intdiv($s, 60);
        $r = $s % 60;

        if ($m > 0) {
            return "{$m}m {$r}s";
        }

        return "{$r}s";
    }
}
