<?php

namespace App\Providers;

use App\Console\Commands\ServeCommand;
use Illuminate\Foundation\Console\ServeCommand as IlluminateServeCommand;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Lazy `serve` resolves Illuminate\Foundation\Console\ServeCommand from the container;
        // rebinding ensures the php -S child always gets -d upload/post limits (see App\Console\Commands\ServeCommand).
        $this->app->singleton(IlluminateServeCommand::class, fn () => new ServeCommand);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Paginator::useBootstrapFive();
    }
}
