<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Call extends Model
{
    use HasFactory;

    public const SENTIMENT_POSITIVE = 'positive';

    public const SENTIMENT_NEUTRAL = 'neutral';

    public const SENTIMENT_NEGATIVE = 'negative';

    /**
     * @var list<string>
     */
    protected $fillable = [
        'audio_file_path',
        'transcript',
        'transcript_segments',
        'ai_summary',
        'conversation_quality',
        'sentiment',
        'sentiment_confidence',
        'overall_call_score',
        'call_score_explanation',
        'agent_talk_time_seconds',
        'customer_talk_time_seconds',
        'keywords',
        'discovery_coverage',
        'action_items',
        'positive_observations',
        'negative_observations',
        'performance_metrics',
        'performance_metric_reasons',
        'duration_seconds',
        'customer_tone_timeline',
    ];

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'overall_call_score' => 'decimal:1',
            'sentiment_confidence' => 'decimal:2',
            'agent_talk_time_seconds' => 'integer',
            'customer_talk_time_seconds' => 'integer',
            'duration_seconds' => 'integer',
            'transcript_segments' => 'array',
            'keywords' => 'array',
            'discovery_coverage' => 'array',
            'action_items' => 'array',
            'positive_observations' => 'array',
            'negative_observations' => 'array',
            'performance_metrics' => 'array',
            'performance_metric_reasons' => 'array',
            'customer_tone_timeline' => 'array',
        ];
    }

    /**
     * @return array<int, string>
     */
    public static function sentiments(): array
    {
        return [
            self::SENTIMENT_POSITIVE,
            self::SENTIMENT_NEUTRAL,
            self::SENTIMENT_NEGATIVE,
        ];
    }
}
