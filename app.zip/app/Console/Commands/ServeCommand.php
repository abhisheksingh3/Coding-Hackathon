<?php

namespace App\Console\Commands;

use Illuminate\Foundation\Console\ServeCommand as IlluminateServeCommand;

/**
 * The built-in server is started as a separate `php -S` process; it does not inherit
 * CLI -d flags from the parent `php artisan serve`. Without these, upload_max_filesize
 * often stays at 2M, so ~1.4MB files work but 3MB+ fail.
 */
class ServeCommand extends IlluminateServeCommand
{
    protected function serverCommand()
    {
        $server = file_exists(base_path('server.php'))
            ? base_path('server.php')
            : base_path('vendor/laravel/framework/src/Illuminate/Foundation/resources/server.php');

        return [
            \Illuminate\Support\php_binary(),
            '-d', 'upload_max_filesize=512M',
            '-d', 'post_max_size=512M',
            '-d', 'memory_limit=512M',
            '-S',
            $this->host().':'.$this->port(),
            $server,
        ];
    }
}
