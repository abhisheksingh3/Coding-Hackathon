<?php

namespace App\Services;

use App\Models\Call;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class OpenAiCallAnalysisService
{
    /**
     * @return array{
     *     text: string,
     *     duration_seconds: int|null,
     *     segments: list<array{start: float, end: float, text: string}>
     * }
     */
    public function transcribe(string $absolutePath, string $originalFilename): array
    {
        $apiKey = $this->apiKey();
        $model = config('services.openai.transcription_model');

        $response = Http::withToken($apiKey)
            ->timeout((int) config('services.openai.timeout_transcription'))
            ->attach(
                'file',
                file_get_contents($absolutePath),
                $originalFilename ?: basename($absolutePath)
            )
            ->post('https://api.openai.com/v1/audio/transcriptions', [
                'model' => $model,
                'response_format' => 'verbose_json',
            ]);

        $this->throwUnlessOk($response, 'Whisper transcription failed');

        $text = $response->json('text');
        if (! is_string($text) || $text === '') {
            throw new RuntimeException('Whisper returned an empty transcript.');
        }

        $durationRaw = $response->json('duration');
        $durationSeconds = is_numeric($durationRaw) ? (int) round((float) $durationRaw) : null;

        $segments = [];
        foreach ($response->json('segments', []) as $seg) {
            if (! is_array($seg)) {
                continue;
            }
            $t = trim((string) ($seg['text'] ?? ''));
            if ($t === '') {
                continue;
            }
            $segments[] = [
                'start' => (float) ($seg['start'] ?? 0),
                'end' => (float) ($seg['end'] ?? 0),
                'text' => $t,
            ];
        }

        return [
            'text' => $text,
            'duration_seconds' => $durationSeconds,
            'segments' => $segments,
        ];
    }

    /**
     * @return array{
     *     ai_summary: string,
     *     conversation_quality: string,
     *     sentiment: string,
     *     overall_call_score: float,
     *     keywords: list<string>,
     *     action_items: list<string>,
     *     positive_observations: list<string>,
     *     negative_observations: list<string>,
     *     performance_metrics: array<string, float|int>,
     *     performance_metric_reasons: array<string, string>,
     *     sentiment_confidence: float|null,
     *     call_score_explanation: string|null,
     *     agent_talk_time_seconds: int|null,
     *     customer_talk_time_seconds: int|null,
     *     discovery_coverage: list<array{topic: string, asked: bool}>
     * }
     */
    public function analyzeTranscript(string $transcript, ?int $durationSeconds): array
    {
        $apiKey = $this->apiKey();
        $model = config('services.openai.analysis_model');

        $topics = config('sales_discovery.topics', []);
        $topics = is_array($topics) ? $topics : [];
        $topicLines = implode("\n", array_map(fn (string $t) => '- '.$t, $topics));

        $durationNote = $durationSeconds !== null && $durationSeconds > 0
            ? "Recording length: approximately {$durationSeconds} seconds."
            : 'Recording length: unknown.';

        $system = <<<'PROMPT'
You analyze B2B / retail sales phone calls (e.g. kitchen remodeling, home improvement). Respond with a single JSON object only (no markdown).

Required JSON shape:
{
  "summary": "string: purpose, main topics, and outcome of the call",
  "conversation_quality": "string: 2–4 sentences on pacing, structure, and engagement (was the rep listening, monologuing, discovery depth)",
  "sentiment": "positive" | "neutral" | "negative" (customer emotional tone overall),
  "sentiment_confidence": number 0–1 (confidence in that label; lower when mixed signals, sparse transcript, or ambiguous tone)",
  "call_score": number 0–10 (overall quality: sentiment, rep behavior, professionalism, outcome clarity),
  "call_score_explanation": "string: 2–4 sentences why this score fits—what helped, what hurt, what was unclear; be specific to this transcript",
  "agent_talk_percent": integer 0–100 (estimated % of time the sales rep spoke),
  "customer_talk_percent": integer 0–100 (estimated % of time the customer/prospect spoke; should sum to ~100 with agent_talk_percent),
  "keywords": ["short topical keywords or phrases discussed"],
  "action_items": ["2–6 strings: commitments, next steps, and implied follow-ups"],
  "positive_observations": ["what the rep did well"],
  "negative_observations": ["gaps, risks, coaching opportunities"],
  "discovery_coverage": [
    {"topic": "exact topic string from the provided list", "asked": true or false}
  ],
  "agent_performance": {
    "communication": number 0–10,
    "politeness": number 0–10,
    "knowledge": number 0–10,
    "problem_handling": number 0–10,
    "listening": number 0–10
  },
  "agent_performance_reasons": {
    "communication": "1–2 sentences citing observable behavior (not generic praise)",
    "politeness": "same",
    "knowledge": "same",
    "problem_handling": "same",
    "listening": "same"
  },
  "customer_tone_timeline": [
    {
      "start": number (seconds from beginning of call, >= 0),
      "end": number (seconds, > start),
      "tone": one of "polite" | "cooperative" | "curious" | "neutral" | "hesitant" | "tense" | "frustrated" | "defensive" | "aggressive" | "hostile",
      "hint": "short phrase: what in the dialogue suggested this (optional)"
    }
  ]
}

Writing style:
- Sound like a sharp human coach, not a template. Vary sentence openings; do not start every bullet with the same phrase (e.g. avoid repeating "The rep" or "The customer" at the start of each line).
- Mix short and longer sentences; occasional natural contractions are fine.
- Keep positive_observations and negative_observations stylistically distinct; strengths can read warmer, gaps more direct.
- Each agent_performance_reasons value must be unique and reference something concrete from the call—never duplicate the same wording across metrics.
- Avoid repeating identical phrases between summary and conversation_quality; each field should add non-overlapping insight.

Rules for customer_tone_timeline:
- Model ONLY the customer/prospect (not the sales rep). Use 5–18 contiguous segments that cover most of the call; start/end in seconds from call start (align with dialogue order).
- "polite" = warm/courteous; "cooperative" = engaged/helpful; "curious" = asking/shopping; "neutral" = flat/factual; "hesitant" = unsure; "tense" = skeptical/guarded; "frustrated" = annoyed/impatient; "defensive" = pushback; "aggressive" = confrontational/demanding; "hostile" = threatening/extreme — use sparingly and only if clearly supported by wording.
- Segments must not overlap; sort by time; last end should be near recording duration when known.

Rules:
- Include every discovery topic from the user message exactly once in discovery_coverage with the same spelling.
- If unsure on talk-time split, infer from dialogue patterns (questions vs long rep monologues).
- All agent_performance values must be numbers 0–10. agent_performance_reasons must include all five keys: communication, politeness, knowledge, problem_handling, listening.
- sentiment_confidence: lower when the transcript is thin, cues conflict, or the customer is mostly neutral with brief spikes.
- action_items: For any substantive call, output at least 2 items whenever possible—even if the call was negative or ended without agreement. Include explicit promises ("Send revised quote"), customer-stated next steps ("Shop another vendor", "Review contract at home"), recovery/coaching ("Manager should call customer", "Clarify line-item pricing in writing"), and compliance ("Document complaint", "Update CRM with objection"). Use [] only if the transcript is empty or has no possible follow-ups at all.
- Use empty arrays for other fields only when truly nothing applies.
PROMPT;

        $userContent = <<<TXT
{$durationNote}

Discovery topics (each must appear once in discovery_coverage with asked true/false):
{$topicLines}

Call transcript:

{$transcript}
TXT;

        $temperature = (float) config('services.openai.analysis_temperature', 0.65);
        $temperature = max(0.0, min(2.0, $temperature));

        $response = Http::withToken($apiKey)
            ->timeout((int) config('services.openai.timeout_analysis'))
            ->post('https://api.openai.com/v1/chat/completions', [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $system],
                    ['role' => 'user', 'content' => $userContent],
                ],
                'temperature' => $temperature,
                'response_format' => ['type' => 'json_object'],
            ]);

        $this->throwUnlessOk($response, 'GPT analysis failed');

        $content = $response->json('choices.0.message.content');
        if (! is_string($content) || $content === '') {
            throw new RuntimeException('GPT returned an empty response.');
        }

        /** @var array<string, mixed> $data */
        $data = json_decode($content, true, flags: JSON_THROW_ON_ERROR);

        return $this->normalizeAnalysis($data, $durationSeconds);
    }

    private function apiKey(): string
    {
        $key = config('services.openai.key');
        if (! is_string($key) || $key === '') {
            throw new RuntimeException('OPENAI_API_KEY is not set.');
        }

        return $key;
    }

    /**
     * @param  \Illuminate\Http\Client\Response  $response
     */
    private function throwUnlessOk($response, string $message): void
    {
        if ($response->successful()) {
            return;
        }

        $body = $response->json();
        $detail = is_array($body) ? ($body['error']['message'] ?? $response->body()) : $response->body();

        throw new RuntimeException($message.': '.$detail);
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{
     *     ai_summary: string,
     *     conversation_quality: string,
     *     sentiment: string,
     *     overall_call_score: float,
     *     keywords: list<string>,
     *     action_items: list<string>,
     *     positive_observations: list<string>,
     *     negative_observations: list<string>,
     *     performance_metrics: array<string, float|int>,
     *     performance_metric_reasons: array<string, string>,
     *     sentiment_confidence: float|null,
     *     call_score_explanation: string|null,
     *     agent_talk_time_seconds: int|null,
     *     customer_talk_time_seconds: int|null,
     *     discovery_coverage: list<array{topic: string, asked: bool}>
     * }
     */
    private function normalizeAnalysis(array $data, ?int $durationSeconds): array
    {
        $sentiment = strtolower((string) ($data['sentiment'] ?? ''));
        if (! in_array($sentiment, Call::sentiments(), true)) {
            $sentiment = Call::SENTIMENT_NEUTRAL;
        }

        $score = $data['call_score'] ?? null;
        $score = is_numeric($score) ? (float) $score : 5.0;
        $score = max(0, min(10, round($score, 1)));

        $sentimentConfidence = $this->normalizeSentimentConfidence($data['sentiment_confidence'] ?? null);

        $scoreExplanation = trim((string) ($data['call_score_explanation'] ?? ''));

        $perf = $data['agent_performance'] ?? [];
        $perf = is_array($perf) ? $perf : [];

        $metrics = [];
        foreach (['communication', 'politeness', 'knowledge', 'problem_handling', 'listening'] as $key) {
            $v = $perf[$key] ?? null;
            $n = is_numeric($v) ? (float) $v : 5.0;
            $metrics[$key] = max(0, min(10, round($n, 1)));
        }

        $agentPct = $data['agent_talk_percent'] ?? null;
        $custPct = $data['customer_talk_percent'] ?? null;
        $agentPct = is_numeric($agentPct) ? max(0, min(100, (int) round((float) $agentPct))) : null;
        $custPct = is_numeric($custPct) ? max(0, min(100, (int) round((float) $custPct))) : null;

        if ($agentPct !== null && $custPct === null) {
            $custPct = max(0, 100 - $agentPct);
        }
        if ($custPct !== null && $agentPct === null) {
            $agentPct = max(0, 100 - $custPct);
        }

        $agentSec = null;
        $custSec = null;
        if ($durationSeconds !== null && $durationSeconds > 0 && $agentPct !== null) {
            $agentSec = (int) round($durationSeconds * $agentPct / 100);
            $custSec = max(0, $durationSeconds - $agentSec);
        }

        $timeline = $this->normalizeCustomerToneTimeline($data['customer_tone_timeline'] ?? [], $durationSeconds);

        $metricReasons = $this->normalizePerformanceMetricReasons($data['agent_performance_reasons'] ?? []);

        return [
            'ai_summary' => trim((string) ($data['summary'] ?? '')) ?: 'No summary generated.',
            'conversation_quality' => trim((string) ($data['conversation_quality'] ?? '')) ?: 'No conversation quality notes.',
            'sentiment' => $sentiment,
            'sentiment_confidence' => $sentimentConfidence,
            'overall_call_score' => $score,
            'call_score_explanation' => $scoreExplanation !== '' ? $scoreExplanation : null,
            'keywords' => $this->stringList($data['keywords'] ?? []),
            'action_items' => $this->stringList($data['action_items'] ?? []),
            'positive_observations' => $this->stringList($data['positive_observations'] ?? []),
            'negative_observations' => $this->stringList($data['negative_observations'] ?? []),
            'performance_metrics' => $metrics,
            'performance_metric_reasons' => $metricReasons,
            'agent_talk_time_seconds' => $agentSec,
            'customer_talk_time_seconds' => $custSec,
            'discovery_coverage' => $this->normalizeDiscoveryCoverage($data['discovery_coverage'] ?? []),
            'customer_tone_timeline' => $timeline === [] ? null : $timeline,
        ];
    }

    /**
     * @param  mixed  $raw
     * @return list<array{start: float, end: float, tone: string, hint: string}>
     */
    private function normalizeCustomerToneTimeline(mixed $raw, ?int $durationSeconds): array
    {
        $allowed = [
            'polite', 'cooperative', 'curious', 'neutral', 'hesitant',
            'tense', 'frustrated', 'defensive', 'aggressive', 'hostile',
        ];

        if (! is_array($raw)) {
            return [];
        }

        $maxEnd = $durationSeconds !== null && $durationSeconds > 0 ? (float) $durationSeconds : null;

        $out = [];
        foreach ($raw as $row) {
            if (! is_array($row)) {
                continue;
            }
            $start = (float) ($row['start'] ?? 0);
            $end = (float) ($row['end'] ?? 0);
            $tone = strtolower(trim((string) ($row['tone'] ?? '')));
            if (! in_array($tone, $allowed, true)) {
                $tone = 'neutral';
            }
            $hint = trim((string) ($row['hint'] ?? ''));
            if ($hint !== '' && mb_strlen($hint) > 160) {
                $hint = mb_substr($hint, 0, 157).'…';
            }

            if ($end <= $start || $start < 0) {
                continue;
            }
            if ($maxEnd !== null && $start > $maxEnd + 0.5) {
                continue;
            }
            if ($maxEnd !== null && $end > $maxEnd + 1) {
                $end = $maxEnd;
            }
            if ($end <= $start) {
                continue;
            }

            $out[] = [
                'start' => round($start, 2),
                'end' => round($end, 2),
                'tone' => $tone,
                'hint' => $hint,
            ];
        }

        usort($out, fn (array $a, array $b) => $a['start'] <=> $b['start']);

        return $out;
    }

    /**
     * @param  mixed  $raw
     * @return list<array{topic: string, asked: bool}>
     */
    private function normalizeDiscoveryCoverage(mixed $raw): array
    {
        $topics = config('sales_discovery.topics', []);
        if (! is_array($topics)) {
            $topics = [];
        }

        $askedMap = [];
        if (is_array($raw)) {
            foreach ($raw as $row) {
                if (! is_array($row)) {
                    continue;
                }
                $topic = trim((string) ($row['topic'] ?? ''));
                if ($topic === '') {
                    continue;
                }
                $key = mb_strtolower($topic);
                $askedMap[$key] = filter_var($row['asked'] ?? false, FILTER_VALIDATE_BOOLEAN);
            }
        }

        $out = [];
        foreach ($topics as $topic) {
            if (! is_string($topic) || trim($topic) === '') {
                continue;
            }
            $key = mb_strtolower($topic);
            $out[] = [
                'topic' => $topic,
                'asked' => $askedMap[$key] ?? false,
            ];
        }

        return $out;
    }

    private function normalizeSentimentConfidence(mixed $raw): ?float
    {
        if (! is_numeric($raw)) {
            return null;
        }

        $c = (float) $raw;
        if ($c > 1.0) {
            $c = $c / 100.0;
        }

        return max(0.0, min(1.0, round($c, 2)));
    }

    /**
     * @return array<string, string>
     */
    private function normalizePerformanceMetricReasons(mixed $raw): array
    {
        $keys = ['communication', 'politeness', 'knowledge', 'problem_handling', 'listening'];
        $out = [];

        if (! is_array($raw)) {
            foreach ($keys as $k) {
                $out[$k] = '';
            }

            return $out;
        }

        foreach ($keys as $k) {
            $v = $raw[$k] ?? '';
            if (is_string($v)) {
                $s = trim($v);
            } elseif (is_scalar($v)) {
                $s = trim((string) $v);
            } else {
                $s = '';
            }
            if ($s !== '' && mb_strlen($s) > 600) {
                $s = mb_substr($s, 0, 597).'…';
            }
            $out[$k] = $s;
        }

        return $out;
    }

    /**
     * @param  mixed  $value
     * @return list<string>
     */
    private function stringList(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        $out = [];
        foreach ($value as $item) {
            if (is_string($item) && trim($item) !== '') {
                $out[] = trim($item);
            } elseif (is_scalar($item)) {
                $s = trim((string) $item);
                if ($s !== '') {
                    $out[] = $s;
                }
            }
        }

        return array_values($out);
    }
}
